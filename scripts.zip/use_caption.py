import subprocess
import multiprocessing
import os
from multiprocessing import Pool

def process_line(line):
    """处理单行内容的函数"""
    line = line.strip()  # 移除换行符和首尾空白
    if not line:  # 跳过空行
        return
    
    # 构造命令
    command = ["python", "usual_caption.py", line]
    
    try:
        print(f"Processing: '{line}'")
        # 执行命令并捕获输出
        result = subprocess.run(command, 
                                stdout=subprocess.PIPE, 
                                stderr=subprocess.PIPE,
                                text=True,
                                check=True)
        
        # 打印命令输出
        if result.stdout:
            print(f"Output for '{line}':\n{result.stdout}")
        if result.stderr:
            print(f"Errors for '{line}':\n{result.stderr}")
            
        print(f"Completed: '{line}'")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error processing '{line}': {e}")
        print(f"Command failed with return code {e.returncode}")
        print(f"Error output:\n{e.stderr}")
        return False
    except Exception as e:
        print(f"Unexpected error processing '{line}': {str(e)}")
        return False

def main():
    # 文件路径
    file_path = "/data/tyl/data/tiny-imagenet-200/te.txt"
    
    # 并行进程数
    k = 3
    
    # 读取文件内容
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
    except Exception as e:
        print(f"Error reading file: {str(e)}")
        return
    
    print(f"Found {len(lines)} lines to process")
    
    # 创建进程池
    with Pool(processes=k) as pool:
        # 使用imap_unordered以便在任务完成时立即获取结果
        results = pool.imap_unordered(process