import argparse, os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
import cv2
import torch
import numpy as np
from omegaconf import OmegaConf
from PIL import Image
from tqdm import tqdm, trange
from itertools import islice
import base64
from einops import rearrange
from torchvision.utils import make_grid
from pytorch_lightning import seed_everything
from torch import autocast
from contextlib import nullcontext
from imwatermark import WatermarkEncoder
import re  # 添加正则表达式模块的导入
from ldm.util import instantiate_from_config
from ldm.models.diffusion.ddim import DDIMSampler
from ldm.models.diffusion.plms import PLMSSampler
from ldm.models.diffusion.dpm_solver import DPMSolverSampler

from openai import OpenAI
import requests
from PIL import Image
from transformers import BlipProcessor, BlipForConditionalGeneration

from PIL import Image
from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers.generation import GenerationConfig
from transformers import BitsAndBytesConfig  # 新增导入
from diffusers import DiffusionPipeline
from diffusers.utils import pt_to_pil
import torch
from diffusers import DiffusionPipeline
from diffusers.utils import pt_to_pil
import torch
from huggingface_hub import login
import os
from huggingface_hub import snapshot_download
clas = "dog"
os.environ["HF_HUB_ENABLE_HF_TRANSFER"] = "0"  # 关闭加速
login(token="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") 
#/data/mengchaofan
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
snapshot_download(repo_id="DeepFloyd/IF-I-XL-v1.0", local_dir="/data/tyl/local_models/IF-I-XL", local_dir_use_symlinks=False)
snapshot_download(
    repo_id="DeepFloyd/IF-II-L-v1.0",
    local_dir="/data/tyl/local_models/IF-II-L",
    local_dir_use_symlinks=False
)
# stage 1
stage_1 = DiffusionPipeline.from_pretrained("/data/tyl/local_models/IF-I-XL",  local_files_only=True,variant="fp16", torch_dtype=torch.float16)
stage_1.enable_xformers_memory_efficient_attention()  # remove line if torch.__version__ >= 2.0.0
stage_1.enable_model_cpu_offload()

# stage 2
stage_2 = DiffusionPipeline.from_pretrained(
    "/data/tyl/local_models/IF-II-L", local_files_only=True, text_encoder=None, variant="fp16", torch_dtype=torch.float16
)
stage_2.enable_xformers_memory_efficient_attention()  # remove line if torch.__version__ >= 2.0.0
stage_2.enable_model_cpu_offload()

# stage 3
#safety_modules = {"feature_extractor": stage_1.feature_extractor, "safety_checker": stage_1.safety_checker,
#                  "watermarker": stage_1.watermarker}
#stage_3 = DiffusionPipeline.from_pretrained("stabilityai/stable-diffusion-x4-upscaler", **safety_modules,
#                                            torch_dtype=torch.float16)
#stage_3.enable_xformers_memory_efficient_attention()  # remove line if torch.__version__ >= 2.0.0
#stage_3.enable_model_cpu_offload()


def gener(prompt):
    # 生成图像的核心逻辑
    prompt_embeds, negative_embeds = stage_1.encode_prompt(prompt)
    generator = torch.manual_seed(0)
    
    # 生成图像
    image = stage_1(
        prompt_embeds=prompt_embeds, 
        negative_prompt_embeds=negative_embeds, 
        generator=generator, 
        output_type="pt"
    ).images
    #pt_to_pil(image)[0].save("./if_stage_I.png")
    image = stage_2(
        image=image, 
        prompt_embeds=prompt_embeds, 
        negative_prompt_embeds=negative_embeds, 
        generator=generator,
        output_type="pt"
    ).images

    # 自动生成递增文件名
    save_dir = "./"
    
    # 确保目录存在
    os.makedirs(save_dir, exist_ok=True)
    
    # 获取现有文件的最大编号
    existing_files = os.listdir(save_dir)
    max_num = 0
    for filename in existing_files:
        # 使用正则匹配纯数字文件名
        match = re.fullmatch(r"(\d+)\.png", filename)
        if match:
            current_num = int(match.group(1))
            if current_num > max_num:
                max_num = current_num

    # 生成新文件名
    new_filename = f"{max_num + 1}.png"
    save_path = os.path.join(save_dir, new_filename)
    
    # 保存图像
    pt_to_pil(image)[0].save(save_path)
    print(f"成功保存: {save_path}")

if __name__ == "__main__":

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    line="This image shows an older man wearing a black tuxedo and bow tie. He has white hair and a serious expression on his face. His eyes are blue and his nose is straight. He has a clean-shaven face and a well-groomed mustache. His lips are thin and his chin is pointed. His hands are clasped behind his back, as if he is posing for a photograph."
    gener(line)
               
