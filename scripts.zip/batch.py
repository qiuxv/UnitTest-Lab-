import os
import subprocess
import argparse
from multiprocessing import Pool
from functools import partial

def process_category(class_name, script_path):
    """处理单个类别"""
    print(f"开始处理类别: {class_name}")
    
    # 构建命令
    command = [
        "python", 
        script_path,
        "--class_name", 
        class_name
    ]
    
    # 执行命令
    result = subprocess.run(
        command, 
        capture_output=True, 
        text=True
    )
    
    # 输出结果
    if result.returncode == 0:
        print(f"类别 {class_name} 处理完成")
        return (class_name, True, result.stdout)
    else:
        print(f"类别 {class_name} 处理失败: {result.stderr}")
        return (class_name, False, result.stderr)

def main():
    parser = argparse.ArgumentParser(description='批量处理图像描述生成')
    parser.add_argument('--data_dir', type=str, 
                        default='/data/tyl/data/tiny-imagenet-200/temp', 
                        help='包含类别文件夹的根目录')
    parser.add_argument('--script_path', type=str, 
                        default='new_usual_caption.py', 
                        help='图像处理脚本路径')
    parser.add_argument('--concurrency', type=int, default=4, 
                        help='并发进程数')
    
    args = parser.parse_args()
    
    # 获取所有子文件夹名称
    categories = []
    for item in os.listdir(args.data_dir):
        item_path = os.path.join(args.data_dir, item)
        if os.path.isdir(item_path):
            categories.append(item)
    
    if not categories:
        print(f"在目录 {args.data_dir} 中未找到子文件夹")
        return
    
    print(f"找到 {len(categories)} 个类别:")
    for i, cat in enumerate(categories):
        print(f"  {i+1}. {cat}")
    
    # 创建并发处理池
    with Pool(processes=args.concurrency) as pool:
        # 使用partial绑定script_path参数
        process_func = partial(process_category, script_path=args.script_path)
        
        # 并发处理所有类别
        results = pool.map(process_func, categories)
    
    # 输出总结结果
    print("\n===== 处理总结 =====")
    success_count = sum(1 for _, success, _ in results if success)
    failed_count = len(results) - success_count
    
    print(f"成功处理: {success_count} 个类别")
    print(f"处理失败: {failed_count} 个类别")
    
    if failed_count > 0:
        print("\n处理失败的类别:")
        for name, success, error in results:
            if not success:
                print(f"  - {name}: {error.splitlines()[0]}")

if __name__ == "__main__":
    main()