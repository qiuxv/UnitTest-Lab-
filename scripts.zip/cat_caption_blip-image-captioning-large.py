import os
import torch

torch.set_grad_enabled(False)
from PIL import Image
from transformers import Blip2Processor, Blip2ForConditionalGeneration
import torch
from transformers import BlipProcessor, BlipForConditionalGeneration
from PIL import Image

# 图生文caption
def caption(image_path):
    processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-large")
    model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-large").to("cuda")
    # 从本地加载图片
    local_image_path = image_path  # 替换为您的本地图片路径
    raw_image = Image.open(local_image_path).convert('RGB')
    text = ""
    # unconditional image captioning
    inputs = processor(raw_image, return_tensors="pt").to("cuda")
    generated_ids = model.generate(**inputs,
                                   max_length=50,
                                   min_length=30,
                                   length_penalty=0.3,  # 长度惩罚
                                   top_k=50,
                                   penalty_alpha=0.6,
                                   temperature=0.7,
                                   do_sample=True,
                                   top_p=0.95,  # 核采样
                                   num_beams=10,  # 搜索束的宽度
                                   early_stopping=True,  # 提前停止生成
                                   no_repeat_ngram_size=4,  # 避免重复的4元组
                                   num_return_sequences=1)
    stra = processor.batch_decode(generated_ids, skip_special_tokens=True)
    return stra[0]


def save_generated_files(generated_files, save_path):
    with open(save_path, "a") as f:
        for filename in generated_files:
            f.write(filename + "\n")


def load_generated_files(save_path):
    generated_files = set()
    if os.path.exists(save_path):
        with open(save_path, "r") as f:
            for line in f:
                generated_files.add(line.strip())
    return generated_files


def generate_captions(folder_path, classes):
    supported_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.gif']  # 支持的图片格式
    caption_list = []
    caption_save_path = os.path.join("/data/tyl/data/captions/origin/blip-image-captioning-large/train/cat.txt")
    generated_files_save_path = os.path.join("/data/tyl/data/generated/origin/blip-image-captioning-large/train/cat.txt",
                                           )
    generated_files = load_generated_files(generated_files_save_path)

    for filename in os.listdir(folder_path):
        if any(filename.lower().endswith(ext) for ext in supported_extensions):
            image_path = os.path.join(folder_path, filename)
            # 检查是否已经生成过该图片
            if filename in generated_files:
                print(f"Skipping already generated image: {filename}")
                continue

            print(filename)
            generated_caption = caption(image_path)
            caption_list.append(generated_caption)
            print("caption:", generated_caption)
            generated_files.add(filename)
            # 定期保存已生成的文件集合
            if len(generated_files) % 10 == 0:  # 每处理10张图片保存一次
                with open(generated_files_save_path, 'a', encoding='utf-8') as f:
                    f.write(filename + "\n")
            with open(caption_save_path, 'a', encoding='utf-8') as f:
                f.write(generated_caption + "\n")
    return


if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    folder_path = "/data/tyl/data/dog_and_cat/origin/train/cat"

    generate_captions(folder_path, "cat")
