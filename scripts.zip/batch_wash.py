import subprocess
import threading
from queue import Queue
import os

def worker(queue):
    """工作线程函数，从队列中获取任务并执行"""
    while True:
        item = queue.get()
        if item is None:
            break
        class_name, output_file = item
        
        # 构建命令
        command = ["python", "new_wash.py", class_name]
        
        # 执行命令
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                check=True
            )
            status = "成功"
            message = result.stdout
        except subprocess.CalledProcessError as e:
            status = "失败"
            message = e.stderr
        
        # 记录执行结果
        with open(output_file, "a", encoding="utf-8") as f:
            f.write(f"类别: {class_name}\n状态: {status}\n")
            f.write(f"输出:\n{message}\n")
            f.write("=" * 50 + "\n")
        
        queue.task_done()

def main():
    # 输入文件路径
    class_file = "/home/tyl/blip-image-captioning-base/toimage/scripts/class.txt"
    
    # 输出结果文件路径
    output_file = "/home/tyl/blip-image-captioning-base/toimage/scripts/concurrency_results.txt"
    
    # 创建队列和线程池
    queue = Queue()
    num_workers = 50  # 并发线程数，可以根据需要调整
    threads = []
    
    # 启动工作线程
    for _ in range(num_workers):
        t = threading.Thread(target=worker, args=(queue,))
        t.start()
        threads.append(t)
    
    # 读取类别文件并添加任务到队列
    try:
        with open(class_file, "r", encoding="utf-8") as f:
            for line in f:
                class_name = line.strip()
                if class_name:  # 跳过空行
                    queue.put((class_name, output_file))
    except FileNotFoundError:
        print(f"错误: 未找到类别文件 {class_file}")
        # 停止所有工作线程
        for _ in range(num_workers):
            queue.put(None)
        for t in threads:
            t.join()
        return
    
    # 等待所有任务完成
    queue.join()
    
    # 停止所有工作线程
    for _ in range(num_workers):
        queue.put(None)
    for t in threads:
        t.join()
    
    print(f"所有任务已完成，结果保存在 {output_file}")

if __name__ == "__main__":
    main()