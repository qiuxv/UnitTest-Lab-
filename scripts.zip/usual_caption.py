import os
import torch

torch.set_grad_enabled(False)
from PIL import Image
from transformers import Blip2Processor, Blip2ForConditionalGeneration
import torch
from transformers import BlipProcessor, BlipForConditionalGeneration
from PIL import Image
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
model="blip-image-captioning-large"
model_name = "Salesforce/"+model
clas="lemon"
#blip-image-captioning-large    1
#Salesforce/blip2-opt-2.7b   2
# 图生文caption
def caption_2(image_path):
   
    #blip-image-captioning-large
    #blip2-opt-2.7b
    processor = Blip2Processor.from_pretrained(model_name)
    model = Blip2ForConditionalGeneration.from_pretrained(
        model_name,
        torch_dtype=torch.float16,
        device_map="auto"
    )

    image = Image.open(image_path).convert('RGB')

    # 添加文本提示模板
    prompt = ""

    # 同时处理图像和文本输入
    inputs = processor(
        images=image,
        text=prompt,  # 新增文本提示
        return_tensors="pt"
    ).to(model.device)

    # 调整生成参数
    generated_ids = model.generate(
        **inputs,
        max_new_tokens=300,  # 增加输出长度限制
        do_sample=True,  # 启用采样模式
        temperature=0.8,  # 提高创造性（0.1-1.0）
        top_p=0.9,  # 核采样参数
        repetition_penalty=1.5,  # 抑制重复内容
        num_beams=5,  # 使用beam search
        early_stopping=True
    )

    return processor.decode(generated_ids[0], skip_special_tokens=True)

def caption_1(image_path):
    processor = BlipProcessor.from_pretrained(model_name)
    model = BlipForConditionalGeneration.from_pretrained(model_name).to("cuda")
    # 从本地加载图片
    local_image_path = image_path  # 替换为您的本地图片路径
    raw_image = Image.open(local_image_path).convert('RGB')
    #text = clas
    # unconditional image captioning
    inputs = processor(raw_image, return_tensors="pt").to("cuda")
    generated_ids = model.generate(**inputs,
                                   max_length=50,
                                   min_length=30,
                                   length_penalty=0.3,  # 长度惩罚
                                   top_k=50,
                                   penalty_alpha=0.6,
                                   temperature=0.7,
                                   do_sample=True,
                                   top_p=0.95,  # 核采样
                                   num_beams=10,  # 搜索束的宽度
                                   early_stopping=True,  # 提前停止生成
                                   no_repeat_ngram_size=4,  # 避免重复的4元组
                                   num_return_sequences=1)
    stra = processor.batch_decode(generated_ids, skip_special_tokens=True)
    return stra[0]

def save_generated_files(generated_files, save_path):
    with open(save_path, "a") as f:
        for filename in generated_files:
            f.write(filename + "\n")


def load_generated_files(save_path):
    generated_files = set()
    if os.path.exists(save_path):
        with open(save_path, "r") as f:
            for line in f:
                generated_files.add(line.strip())
    return generated_files


def generate_captions(folder_path, classes):
    supported_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.gif']  # 支持的图片格式
    caption_list = []
    caption_save_path = os.path.join("./"+clas+".txt")
    generated_files_save_path = os.path.join("./gen_"+clas+".txt",
                                           )
    generated_files = load_generated_files(generated_files_save_path)

    for filename in os.listdir(folder_path):
        if any(filename.lower().endswith(ext) for ext in supported_extensions):
            image_path = os.path.join(folder_path, filename)
            # 检查是否已经生成过该图片
            if filename in generated_files:
                print(f"Skipping already generated image: {filename}")
                continue

            print(filename)
            generated_caption = caption_1(image_path)                 ####################
            caption_list.append(generated_caption)
            print("caption:", generated_caption)
            generated_files.add(filename)
            # 定期保存已生成的文件集合
            if len(generated_files) % 1 == 0:  # 每处理10张图片保存一次
                with open(generated_files_save_path, 'a', encoding='utf-8') as f:
                    f.write(filename + "\n")
            with open(caption_save_path, 'a', encoding='utf-8') as f:
                f.write(generated_caption + "\n")
    return


if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    folder_path = "/data/tyl/data/tiny-imagenet-200/temp/"+clas
    generate_captions(folder_path, clas)
