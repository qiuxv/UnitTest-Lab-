import os
import torch
import argparse
from PIL import Image
from transformers import BlipProcessor, BlipForConditionalGeneration

torch.set_grad_enabled(False)
os.environ["CUDA_VISIBLE_DEVICES"] = "1"

class ImageCaptionGenerator:
    def __init__(self, class_name="lemon"):
        """初始化图像描述生成器"""
        self.class_name = class_name
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        
        # 固定使用 blip-image-captioning-large 模型
        model_name = "Salesforce/blip-image-captioning-large"
        self.processor = BlipProcessor.from_pretrained(model_name)
        self.model = BlipForConditionalGeneration.from_pretrained(model_name).to(self.device)
            
        print(f"使用设备: {self.device}")
        print(f"使用模型: {model_name}")
        
        # 确保输出目录存在
        self.output_dir = "./"
        os.makedirs(self.output_dir, exist_ok=True)
        
        # 输出文件路径
        self.caption_save_path = os.path.join(self.output_dir, f"{class_name}.txt")
        self.generated_files_path = os.path.join(self.output_dir, f"gen_{class_name}.txt")
        self.generated_files = self.load_generated_files()
        
        # 调试计数器
        self.total_files = 0
        self.processed_files = 0
        
    def load_generated_files(self):
        """加载已生成的文件列表"""
        generated_files = set()
        if os.path.exists(self.generated_files_path):
            with open(self.generated_files_path, "r") as f:
                for line in f:
                    generated_files.add(line.strip())
            print(f"已加载 {len(generated_files)} 个已处理文件记录")
        return generated_files
        
    def save_generated_files(self):
        """保存已生成的文件列表"""
        with open(self.generated_files_path, "w") as f:
            for filename in self.generated_files:
                f.write(filename + "\n")
        print(f"已保存已处理文件列表，共 {len(self.generated_files)} 个文件")
                
    def generate_caption(self, image_path):
        """生成单张图片的描述"""
        try:
            image = Image.open(image_path).convert('RGB')
            
            # BLIP处理
            inputs = self.processor(image, return_tensors="pt").to(self.device)
            generated_ids = self.model.generate(
                **inputs,
                max_length=50,
                min_length=30,
                length_penalty=0.3,
                top_k=50,
                penalty_alpha=0.6,
                temperature=0.7,
                do_sample=True,
                top_p=0.95,
                num_beams=10,
                early_stopping=True,
                no_repeat_ngram_size=4,
                num_return_sequences=1
            )
            caption = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
                
            self.processed_files += 1
            print(f"已处理 {self.processed_files}/{self.total_files}: {os.path.basename(image_path)} -> {caption[:50]}...")
            return caption
        except Exception as e:
            print(f"处理图片 {image_path} 时出错: {str(e)}")
            with open(os.path.join(self.output_dir, f"error_{self.class_name}.log"), "a") as f:
                f.write(f"处理图片 {image_path} 时出错: {str(e)}\n")
            return None
            
    def generate_captions(self, folder_path):
        """批量生成文件夹中所有图片的描述"""
        supported_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.gif']
        
        if not os.path.exists(folder_path):
            print(f"错误: 输入文件夹不存在: {folder_path}")
            return
            
        image_files = []
        for filename in os.listdir(folder_path):
            if any(filename.lower().endswith(ext) for ext in supported_extensions):
                image_files.append(filename)
                
        self.total_files = len(image_files)
        
        if self.total_files == 0:
            print(f"错误: 在文件夹 {folder_path} 中未找到支持的图片文件")
            return
            
        print(f"找到 {self.total_files} 张图片，开始处理...")
        processed_count = 0
        
        for filename in image_files:
            image_path = os.path.join(folder_path, filename)
            
            if filename in self.generated_files:
                print(f"跳过已处理图片: {filename}")
                continue
                    
            caption = self.generate_caption(image_path)
            
            if caption:
                self.generated_files.add(filename)
                processed_count += 1
                
                with open(self.caption_save_path, 'a', encoding='utf-8') as f:
                    f.write(caption + "\n")
                    
                if processed_count % 10 == 0:
                    self.save_generated_files()
                    print(f"已处理 {processed_count}/{self.total_files} 张图片，保存进度...")
        
        self.save_generated_files()
        print(f"处理完成! 共生成 {processed_count} 个图像描述，保存在 {self.caption_save_path}")

def main():
    parser = argparse.ArgumentParser(description='图像描述生成工具')
    parser.add_argument('--class_name', type=str, required=True, help='类别名称')
    
    args = parser.parse_args()
    
    # 构建图片文件夹路径
    folder_path = f"/data/tyl/data/tiny-imagenet-200/temp/{args.class_name}/images"
    
    # 初始化生成器
    generator = ImageCaptionGenerator(class_name=args.class_name)
    
    # 批量生成描述
    generator.generate_captions(folder_path)

if __name__ == "__main__":
    main()