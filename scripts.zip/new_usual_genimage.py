import argparse
import os
import re
import gc
import torch
import numpy as np
from PIL import Image
from tqdm import tqdm
from transformers import BlipProcessor, BlipForConditionalGeneration
from diffusers import DiffusionPipeline
from diffusers.utils import pt_to_pil
from huggingface_hub import login, snapshot_download

# 解析命令行参数
parser = argparse.ArgumentParser(description='基于DeepFloyd IF模型生成图像')
parser.add_argument('class_name', type=str, help='指定生成图像的类别名称')
args = parser.parse_args()
clas = args.class_name

# 环境配置
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
login(token="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")
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"

# 模型缓存路径
LOCAL_MODELS_DIR = "/data/tyl/local_models"
IF_I_XL_PATH = os.path.join(LOCAL_MODELS_DIR, "IF-I-XL")
IF_II_L_PATH = os.path.join(LOCAL_MODELS_DIR, "IF-II-L")

def download_models():
    """下载模型到本地缓存"""
    if not os.path.exists(IF_I_XL_PATH):
        print(f"正在下载DeepFloyd/IF-I-XL-v1.0到{IF_I_XL_PATH}")
        snapshot_download(repo_id="DeepFloyd/IF-I-XL-v1.0", 
                         local_dir=IF_I_XL_PATH, 
                         local_dir_use_symlinks=False)
    
    if not os.path.exists(IF_II_L_PATH):
        print(f"正在下载DeepFloyd/IF-II-L-v1.0到{IF_II_L_PATH}")
        snapshot_download(repo_id="DeepFloyd/IF-II-L-v1.0",
                         local_dir=IF_II_L_PATH,
                         local_dir_use_symlinks=False)

def load_models():
    """加载图像生成模型"""
    print("正在加载模型...")
    # 阶段1模型 - 低分辨率图像生成
    stage_1 = DiffusionPipeline.from_pretrained(
        IF_I_XL_PATH, 
        local_files_only=True,
        variant="fp16", 
        torch_dtype=torch.float16
    )
    if torch.__version__ < "2.0.0":
        stage_1.enable_xformers_memory_efficient_attention()
    stage_1.enable_model_cpu_offload()
    
    # 阶段2模型 - 高分辨率图像细化
    stage_2 = DiffusionPipeline.from_pretrained(
        IF_II_L_PATH, 
        local_files_only=True, 
        text_encoder=None, 
        variant="fp16", 
        torch_dtype=torch.float16
    )
    if torch.__version__ < "2.0.0":
        stage_2.enable_xformers_memory_efficient_attention()
    stage_2.enable_model_cpu_offload()
    
    return stage_1, stage_2

def gener(prompt, stage_1, stage_2, seed=0):
    """
    根据提示词生成图像
    
    参数:
    - prompt: 文本提示词
    - stage_1: 第一阶段模型
    - stage_2: 第二阶段模型
    - seed: 随机种子
    """
    try:
        # 编码提示词
        prompt_embeds, negative_embeds = stage_1.encode_prompt(prompt)
        generator = torch.manual_seed(seed)
        
        # 第一阶段生成
        image = stage_1(
            prompt_embeds=prompt_embeds, 
            negative_prompt_embeds=negative_embeds, 
            generator=generator, 
            output_type="pt"
        ).images
        
        # 第二阶段细化
        image = stage_2(
            image=image, 
            prompt_embeds=prompt_embeds, 
            negative_prompt_embeds=negative_embeds, 
            generator=generator,
            output_type="pt"
        ).images
        
        # 保存图像
        save_dir = f"/data/tyl/data/tiny-imagenet-200/gner/{clas}"
        os.makedirs(save_dir, exist_ok=True)
        
        # 生成递增文件名
        max_num = 0
        if os.listdir(save_dir):
            existing_files = [f for f in os.listdir(save_dir) if re.fullmatch(r"\d+\.png", f)]
            if existing_files:
                max_num = max(int(f.split('.')[0]) for f in existing_files)
        
        save_path = os.path.join(save_dir, f"{max_num + 1}.png")
        pt_to_pil(image)[0].save(save_path)
        print(f"成功生成: {save_path}")
        
        return save_path
    
    except Exception as e:
        print(f"生成图像时出错: {str(e)}")
        return None
    finally:
        # 清理GPU内存
        del image, prompt_embeds, negative_embeds, generator
        gc.collect()
        torch.cuda.empty_cache()

def main():
    # 下载模型
    download_models()
    
    # 加载模型
    stage_1, stage_2 = load_models()
    
    # 文件路径
    input_path = f"/home/tyl/blip-image-captioning-base/toimage/scripts/washed/{clas}.txt"
    output_path = f"/home/tyl/blip-image-captioning-base/toimage/scripts/gnered{clas}.txt"
    
    # 读取输入文件并去重
    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            unique_lines = list({line.rstrip('\n') for line in f if line.strip()})
        print(f"读取了{len(unique_lines)}条提示词")
    except FileNotFoundError:
        print(f"输入文件 {input_path} 不存在")
        return
    
    # 检查已处理的提示词
    try:
        with open(output_path, 'r', encoding='utf-8') as f:
            saved_lines = {line.rstrip('\n') for line in f}
        new_lines = [line for line in unique_lines if line not in saved_lines]
        print(f"需要生成{len(new_lines)}条新提示词对应的图像")
    except FileNotFoundError:
        new_lines = unique_lines
        print(f"开始全新生成{len(new_lines)}条提示词对应的图像")
    
    # 批量生成图像
    success_count = 0
    for prompt in tqdm(new_lines, desc="生成进度"):
        result = gener(prompt, stage_1, stage_2)
        if result:
            success_count += 1
            # 记录已生成的提示词
            with open(output_path, 'a', encoding='utf-8') as f:
                f.write(f"{prompt}\n")
    
    print(f"图像生成完成! 成功: {success_count}, 失败: {len(new_lines) - success_count}")

if __name__ == "__main__":
    main()