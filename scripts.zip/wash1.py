import time
import os
from openai import OpenAI

client = OpenAI(
    api_key="sk-33c43c4e146142acbb35a7adca0df375",
    base_url="https://api.deepseek.com"
)

input_path = '/home/tyl/blip-image-captioning-base/toimage/Gray_Hair.txt'        # 输入文本文件
output_path = 'output_Gray.txt'      # 输出文本文件
progress_path = 'progress_Gray.txt'  # 记录处理进度的文件

# 读取输入文件
with open(input_path, 'r', encoding='utf-8') as f:
    input_lines = [line.strip() for line in f.readlines() if line.strip()]

# 初始化处理进度
processed_indices = set()
if os.path.exists(progress_path):
    with open(progress_path, 'r', encoding='utf-8') as f:
        processed_indices = set(int(line.strip()) for line in f if line.strip())

# 创建或追加输出文件
output_mode = 'a' if os.path.exists(output_path) else 'w'
output_file = open(output_path, output_mode, encoding='utf-8')

# 创建或追加进度文件
progress_mode = 'a' if os.path.exists(progress_path) else 'w'
progress_file = open(progress_path, progress_mode, encoding='utf-8')

# 逐行处理文本
for idx, desc in enumerate(input_lines):
    if idx in processed_indices:
        continue  # 跳过已处理的行
        
    print(f"处理第 {idx+1} 行: {desc[:50]}...")  # 显示前50个字符

    try:
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {
                    "role": "system",
                    "content": """
User will provide portrait descriptions. If hair color is not mentioned, insert 'grey hair' with minimal changes. If other hair color is mentioned, replace it with 'grey'. If already grey, make no change. Only output the final description.
                    
                    ​"""
                },
                {"role": "user", "content": desc}
            ],
            stream=False
        )
        reply = response.choices[0].message.content.strip()
    except Exception as e:
        reply = f"[ERROR] {str(e)}"
    
    # 保存结果和进度
    output_file.write(reply + '\n')
    progress_file.write(str(idx) + '\n')
    
    # 立即刷新确保写入磁盘
    output_file.flush()
    progress_file.flush()
    
    print(f"处理结果: {reply[:50]}...\n{'='*50}")
    time.sleep(0.5)  # 防止QPS超限

# 关闭文件
output_file.close()
progress_file.close()
print("全部处理完成。")