import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
import torch
import re
import math
from tqdm import tqdm
from PIL import Image
from diffusers import DiffusionPipeline, DPMSolverMultistepScheduler
from diffusers.utils import pt_to_pil
from huggingface_hub import login, snapshot_download

# ========== 配置 ==========
clas = "Gray_Hair"
input_path = "/home/tyl/blip-image-captioning-base/toimage/scripts/output_Gray.txt"
output_path = f"/data/tyl/data/generated/origin/IF-I-XL/train/{clas}.txt"
save_dir = f"/data/tyl/data/dog_and_cat/IF-I-XL/train/{clas}"
BATCH_SIZE = 8
os.makedirs(save_dir, exist_ok=True)

# ========== 登录 & 下载 ==========
login(token="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")
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
snapshot_download("DeepFloyd/IF-I-XL-v1.0", local_dir="/home/tyl/blip-image-captioning-base/toimage/scripts/models/IF-I-XL", local_dir_use_symlinks=False)
snapshot_download("DeepFloyd/IF-II-L-v1.0", local_dir="/home/tyl/blip-image-captioning-base/toimage/scripts/models/IF-II-L", local_dir_use_symlinks=False)

# ========== 模型加载 ==========
stage_1 = DiffusionPipeline.from_pretrained("/data/tyl/local_models/IF-I-XL", local_files_only=True, variant="fp16", torch_dtype=torch.float16)
stage_1.enable_xformers_memory_efficient_attention()
stage_1.enable_model_cpu_offload()
if hasattr(torch, 'compile'):
    stage_1.unet = torch.compile(stage_1.unet)
    print("已启用Stage 1模型编译优化")

stage_2 = DiffusionPipeline.from_pretrained("/data/tyl/local_models/IF-II-L", local_files_only=True, text_encoder=None, variant="fp16", torch_dtype=torch.float16)
stage_2.enable_xformers_memory_efficient_attention()
stage_2.enable_model_cpu_offload()
if hasattr(torch, 'compile'):
    stage_2.unet = torch.compile(stage_2.unet)
    print("已启用Stage 2模型编译优化")

stage_1.scheduler = DPMSolverMultistepScheduler.from_config(stage_1.scheduler.config)
stage_2.scheduler = DPMSolverMultistepScheduler.from_config(stage_2.scheduler.config)
print("已启用DPM-Solver++调度器加速")

# ========== hook 清除函数 ==========
def safe_remove_hook(module, name=None):
    try:
        delattr(module, "_hf_hook")
        if name:
            print(f"已清除 hook: {name}")
    except AttributeError:
        # 完全没有该属性，不打印
        pass
    except Exception as e:
        print(f"跳过 hook 删除错误: {name} -> {e}")


# ========== 生成函数 ==========
def gener_batch(prompts):
    """
    批量生成图像（稳定版本，无hook清理，无offload）
    :param prompts: 文本提示列表
    """
    # 编码 prompt 成 embedding
    prompt_embeds, negative_embeds = stage_1.encode_prompt(prompts)
    generator = torch.manual_seed(0)

    # Stage 1 生成 latent 图像
    images = stage_1(
        prompt_embeds=prompt_embeds,
        negative_prompt_embeds=negative_embeds,
        generator=generator,
        output_type="pt"
    ).images

    # Stage 2 超分辨率精细化
    images = stage_2(
        image=images,
        prompt_embeds=prompt_embeds,
        negative_prompt_embeds=negative_embeds,
        generator=generator,
        output_type="pt"
    ).images

    # 保存路径
    save_dir = f"/data/tyl/data/dog_and_cat/IF-I-XL/train/{clas}"
    os.makedirs(save_dir, exist_ok=True)

    # 自动递增文件名
    existing_files = os.listdir(save_dir)
    max_num = 0
    for filename in existing_files:
        match = re.fullmatch(r"(\d+)\.png", filename)
        if match:
            current_num = int(match.group(1))
            if current_num > max_num:
                max_num = current_num

    # 保存图像
    pil_images = pt_to_pil(images)
    for i, img in enumerate(pil_images):
        new_filename = f"{max_num + i + 1}.png"
        save_path = os.path.join(save_dir, new_filename)
        img.save(save_path)
        print(f"✅ 成功保存: {save_path}")


# ========== 主程序 ==========
if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    with open(input_path, 'r', encoding='utf-8') as f:
        all_lines = [line.strip() for line in f]
        unique_lines = list(dict.fromkeys(all_lines))
        print(f"读取到 {len(all_lines)} 条提示，去重后剩余 {len(unique_lines)} 条")

    try:
        with open(output_path, 'r', encoding='utf-8') as f:
            saved_lines = set(line.strip() for line in f)
            print(f"已加载 {len(saved_lines)} 条已处理记录")
    except FileNotFoundError:
        saved_lines = set()
        print("未找到历史记录文件，将从头开始处理")

    new_lines = [line for line in unique_lines if line not in saved_lines]
    print(f"需要处理的新提示数量: {len(new_lines)}")
    total_batches = math.ceil(len(new_lines) / BATCH_SIZE)

    for i in tqdm(range(0, len(new_lines), BATCH_SIZE), desc="处理进度", total=total_batches):
        batch = new_lines[i:i+BATCH_SIZE]
        try:
            gener_batch(batch)
            with open(output_path, 'a', encoding='utf-8') as f:
                for line in batch:
                    f.write(f"{line}\n")
        except Exception as e:
            print(f"❌ 批次处理失败：{e}")
