import os
import torch

torch.set_grad_enabled(False)
from PIL import Image
from transformers import Blip2Processor, Blip2ForConditionalGeneration
import torch

import os
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'  # 添加在文件开头

model_name = "Salesforce/blip2-opt-2.7b"
print("开始加载模型...")  # 添加调试信息
processor = Blip2Processor.from_pretrained(model_name)
model = Blip2ForConditionalGeneration.from_pretrained(
    model_name,
    torch_dtype=torch.float16,
    device_map="auto"  # 修改为auto，由系统自动分配设备
)
print("模型加载完成")  # 确认模型加载阶段是否通过
model_name = "Salesforce/blip2-opt-2.7b"
processor = Blip2Processor.from_pretrained(model_name)
model = Blip2ForConditionalGeneration.from_pretrained(
    model_name,
    torch_dtype=torch.float16,
    device_map="cuda:1"
)


# 图生文caption
def caption(image_path):
    image = Image.open(image_path).convert('RGB')

    # 添加文本提示模板
    prompt = ""

    # 同时处理图像和文本输入
    inputs = processor(
        images=image,
        text=prompt,  # 新增文本提示
        return_tensors="pt"
    ).to(model.device)

    # 调整生成参数
    generated_ids = model.generate(
        **inputs,
        max_new_tokens=300,  # 增加输出长度限制
        do_sample=True,  # 启用采样模式
        temperature=0.8,  # 提高创造性（0.1-1.0）
        top_p=0.9,  # 核采样参数
        repetition_penalty=1.5,  # 抑制重复内容
        num_beams=5,  # 使用beam search
        early_stopping=True
    )

    return processor.decode(generated_ids[0], skip_special_tokens=True)


def save_generated_files(generated_files, save_path):
    with open(save_path, "a") as f:
        for filename in generated_files:
            f.write(filename + "\n")


def load_generated_files(save_path):
    generated_files = set()
    if os.path.exists(save_path):
        with open(save_path, "r") as f:
            for line in f:
                generated_files.add(line.strip())
    return generated_files


def generate_captions(folder_path, classes):
    supported_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.gif']  # 支持的图片格式
    caption_list = []
    caption_save_path = os.path.join("/data/tyl/data/captions/origin/train/dog.txt")
    generated_files_save_path = os.path.join("/data/tyl/data/generated/origin/train/dog.txt",
                                             )
    generated_files = load_generated_files(generated_files_save_path)

    for filename in os.listdir(folder_path):
        if any(filename.lower().endswith(ext) for ext in supported_extensions):
            image_path = os.path.join(folder_path, filename)
            # 检查是否已经生成过该图片
            if filename in generated_files:
                print(f"Skipping already generated image: {filename}")
                continue

            print(filename)
            generated_caption = caption(image_path)
            caption_list.append(generated_caption)
            print("caption:", generated_caption)
            generated_files.add(filename)
            # 定期保存已生成的文件集合
            if len(generated_files) % 10 == 0:  # 每处理10张图片保存一次
                with open(generated_files_save_path, 'a', encoding='utf-8') as f:
                    f.write(filename + "\n")
            with open(caption_save_path, 'a', encoding='utf-8') as f:
                f.write(generated_caption + "\n")
    return


if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    folder_path = "/data/tyl/data/dog_and_cat/origin/train/dog"

    generate_captions(folder_path, "dog")
