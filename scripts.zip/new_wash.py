import time
import os
import sys
from openai import OpenAI

def main():
    if len(sys.argv) != 2:
        print("使用方法: python wash.py [类别名]")
        sys.exit(1)
    
    clas = sys.argv[1]
    print(f"处理类别: {clas}")

    client = OpenAI(
        api_key="sk-33c43c4e146142acbb35a7adca0df375",
        base_url="https://api.deepseek.com"
    )

    input_path = f'/home/tyl/blip-image-captioning-base/toimage/scripts/unwash/{clas}.txt'
    output_path = f'/home/tyl/blip-image-captioning-base/toimage/scripts/washed/{clas}.txt'
    progress_path = f'/home/tyl/blip-image-captioning-base/toimage/scripts/process{clas}.txt'

    # 读取输入文件
    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            input_lines = [line.strip() for line in f.readlines() if line.strip()]
    except FileNotFoundError:
        print(f"错误: 输入文件 {input_path} 不存在")
        sys.exit(1)

    # 初始化处理进度
    processed_indices = set()
    if os.path.exists(progress_path):
        with open(progress_path, 'r', encoding='utf-8') as f:
            processed_indices = set(int(line.strip()) for line in f if line.strip())

    # 创建或追加输出文件
    output_mode = 'a' if os.path.exists(output_path) else 'w'
    output_file = open(output_path, output_mode, encoding='utf-8')

    # 创建或追加进度文件
    progress_mode = 'a' if os.path.exists(progress_path) else 'w'
    progress_file = open(progress_path, progress_mode, encoding='utf-8')

    # 逐行处理文本
    for idx, desc in enumerate(input_lines):
        if idx in processed_indices:
            continue  # 跳过已处理的行
            
        print(f"处理第 {idx+1} 行: {desc[:50]}...")  # 显示前50个字符

        try:
            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=[
                    {
                        "role": "system",
                        "content": f"If the description subject is not {clas}, change the description subject to {clas}. If there is no description subject, add a description of {clas}. Only output the processed description."
                    },
                    {"role": "user", "content": desc}
                ],
                stream=False
            )
            reply = response.choices[0].message.content.strip()
        except Exception as e:
            reply = f"[ERROR] {str(e)}"
        
        # 保存结果和进度
        output_file.write(reply + '\n')
        progress_file.write(str(idx) + '\n')
        
        # 立即刷新确保写入磁盘
        output_file.flush()
        progress_file.flush()
        
        print(f"处理结果: {reply[:50]}...\n{'='*50}")
        time.sleep(0.5)  # 防止QPS超限

    # 关闭文件
    output_file.close()
    progress_file.close()
    print("全部处理完成。")

if __name__ == "__main__":
    main()