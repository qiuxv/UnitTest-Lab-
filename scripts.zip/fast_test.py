import argparse, os
import cv2
import torch
import numpy as np
from omegaconf import OmegaConf
from PIL import Image
from tqdm import tqdm, trange
from itertools import islice
from einops import rearrange
from torchvision.utils import make_grid
from pytorch_lightning import seed_everything
from torch import autocast
from contextlib import nullcontext
from imwatermark import WatermarkEncoder
from ldm.util import instantiate_from_config
from ldm.models.diffusion.ddim import DDIMSampler
from ldm.models.diffusion.plms import PLMSSampler
from ldm.models.diffusion.dpm_solver import DPMSolverSampler
from transformers import BlipProcessor, BlipForConditionalGeneration

torch.set_grad_enabled(False)
torch.backends.cudnn.benchmark = True

# 全局模型缓存
BLIP_PROCESSOR = None
BLIP_MODEL = None
SD_MODEL = None
SD_SAMPLER = None
WM_ENCODER = WatermarkEncoder()

def initialize_models(opt):
    global BLIP_PROCESSOR, BLIP_MODEL, SD_MODEL, SD_SAMPLER, WM_ENCODER
    
    # 初始化BLIP
    if BLIP_PROCESSOR is None:
        BLIP_PROCESSOR = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-large")
    if BLIP_MODEL is None:
        BLIP_MODEL = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-large").to("cuda")
        BLIP_MODEL.eval()
    
    # 初始化SD模型
    if SD_MODEL is None:
        config = OmegaConf.load(opt.config)
        device = torch.device("cuda") if opt.device == "cuda" else torch.device("cpu")
        SD_MODEL = load_model_from_config(config, opt.ckpt, device)
        
        if opt.plms:
            SD_SAMPLER = PLMSSampler(SD_MODEL, device=device)
        elif opt.dpm:
            SD_SAMPLER = DPMSolverSampler(SD_MODEL, device=device)
        else:
            SD_SAMPLER = DDIMSampler(SD_MODEL, device=device)
    
    WM_ENCODER.set_watermark('bytes', 'SDV2'.encode('utf-8'))

def load_model_from_config(config, ckpt, device=torch.device("cuda"), verbose=False):
    if SD_MODEL is not None:
        return SD_MODEL
    
    print(f"Loading model from {ckpt}")
    if ckpt.endswith(".safetensors"):
        from safetensors import safe_open
        pl_sd = {"state_dict": {}}
        with safe_open(ckpt, framework="pt", device="cpu") as f:
            for key in f.keys():
                pl_sd["state_dict"][key] = f.get_tensor(key)
    else:
        pl_sd = torch.load(ckpt, map_location="cpu", weights_only=False)
    
    sd = pl_sd["state_dict"]
    model = instantiate_from_config(config.model)
    m, u = model.load_state_dict(sd, strict=False)
    
    if device == torch.device("cuda"):
        model.cuda()
    elif device == torch.device("cpu"):
        model.cpu()
        model.cond_stage_model.device = "cpu"
    model.eval()
    return model

def parse_args(classes):
    parser = argparse.ArgumentParser()
    # 添加缺失的 fixed_code 参数
    parser.add_argument("--fixed_code", action='store_true', help="use fixed starting code")
    parser.add_argument("--prompt", type=str, default="a professional photograph")
    parser.add_argument("--outdir", type=str, default=f"/home/mengchaofan/blip-image-captioning-base/toimage/outputs/2image/{classes}")
    parser.add_argument("--steps", type=int, default=50)
    parser.add_argument("--plms", action='store_true')
    parser.add_argument("--dpm", action='store_true')
    parser.add_argument("--ddim_eta", type=float, default=0.0)
    parser.add_argument("--n_iter", type=int, default=3)
    parser.add_argument("--H", type=int, default=512)
    parser.add_argument("--W", type=int, default=512)
    parser.add_argument("--C", type=int, default=4)
    parser.add_argument("--f", type=int, default=8)
    parser.add_argument("--n_samples", type=int, default=3)
    parser.add_argument("--scale", type=float, default=9.0)
    parser.add_argument("--config", type=str, default="configs/stable-diffusion/v2-inference.yaml")
    parser.add_argument("--ckpt", type=str, required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--precision", type=str, default="autocast")
    parser.add_argument("--device", type=str, default="cpu")
    return parser.parse_args()

def process_images_in_folder_front(folder_path, classes):
    initialize_models(opt)
    
    caption_save_path = f"/home/mengchaofan/blip-image-captioning-base/toimage/outputs/2txt/{classes}_front_result.txt"
    generated_files_save_path = f"/home/mengchaofan/blip-image-captioning-base/toimage/outputs/2txt/{classes}_front.txt"
    
    processed_files = set()
    if os.path.exists(generated_files_save_path):
        with open(generated_files_save_path, "r") as f:
            processed_files.update(line.strip() for line in f)
    
    for filename in os.listdir(folder_path):
        if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
            if filename in processed_files:
                print(f"Skipping processed: {filename}")
                continue
                
            image_path = os.path.join(folder_path, filename)
            try:
                raw_image = Image.open(image_path).convert('RGB')
                inputs = BLIP_PROCESSOR(raw_image, 
                    f"Please describe this picture in one sentence ending with {classes}.", 
                    return_tensors="pt").to("cuda")
                
                generated_ids = BLIP_MODEL.generate(
                    **inputs,
                    max_length=50,
                    num_beams=5,
                    early_stopping=True
                )
                caption = BLIP_PROCESSOR.decode(generated_ids[0], skip_special_tokens=True)
                
                with open(caption_save_path, "a", encoding="utf-8") as f:
                    f.write(caption + "\n")
                
                opt.prompt = caption
                generate_images(opt)
                
                with open(generated_files_save_path, "a") as f:
                    f.write(filename + "\n")
                    
            except Exception as e:
                print(f"Error processing {filename}: {str(e)}")

def generate_images(opt):
    seed_everything(opt.seed)
    os.makedirs(opt.outdir, exist_ok=True)
    
    global SD_MODEL, SD_SAMPLER
    
    sample_path = os.path.join(opt.outdir, "samples")
    os.makedirs(sample_path, exist_ok=True)
    base_count = len(os.listdir(sample_path))
    
    # 处理 fixed_code 参数
    start_code = None
    if hasattr(opt, 'fixed_code') and opt.fixed_code:  # 添加属性检查
        start_code = torch.randn([opt.n_samples, opt.C, opt.H//opt.f, opt.W//opt.f], device=SD_MODEL.device)
    
    precision_scope = autocast if opt.precision == "autocast" else nullcontext
    with torch.no_grad(), precision_scope(opt.device), SD_MODEL.ema_scope():
        uc = SD_MODEL.get_learned_conditioning(opt.n_samples * [""]) if opt.scale != 1.0 else None
        c = SD_MODEL.get_learned_conditioning([opt.prompt]*opt.n_samples)
        
        samples, _ = SD_SAMPLER.sample(
            S=opt.steps,
            conditioning=c,
            batch_size=opt.n_samples,
            shape=[opt.C, opt.H//opt.f, opt.W//opt.f],
            verbose=False,
            unconditional_guidance_scale=opt.scale,
            unconditional_conditioning=uc,
            eta=opt.ddim_eta,
            x_T=start_code
        )
        
        x_samples = SD_MODEL.decode_first_stage(samples)
        x_samples = torch.clamp((x_samples + 1.0)/2.0, min=0.0, max=1.0)
        
        for idx, x_sample in enumerate(x_samples):
            img = Image.fromarray((255 * rearrange(x_sample.cpu().numpy(), 'c h w -> h w c')).astype(np.uint8))
            img = put_watermark(img, WM_ENCODER)
            img.save(os.path.join(sample_path, f"{base_count+idx:05}.png"))
            
def put_watermark(img, wm_encoder=None):
    if wm_encoder is not None:
        img = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
        img = wm_encoder.encode(img, 'dwtDct')
        img = Image.fromarray(img[:, :, ::-1])
    return img

if __name__ == "__main__":
    folder = "cat"
    folder_path = "/home/mengchaofan/blip-image-captioning-base/Cat-Dog-Recognition-Project-main/Dataset/train"
    
    opt = parse_args(folder)
    initialize_models(opt)
    
    process_images_in_folder_front(os.path.join(folder_path, folder), folder)