import time
from openai import OpenAI

# 配置DeepSeek API客户端
client = OpenAI(
    api_key="sk-33c43c4e146142acbb35a7adca0df375",
    base_url="https://api.deepseek.com"
)

# 初始化聊天历史
chat_history = [
    {
        "role": "system",
        "content": """
        你现在是DeepSeek助手，一个智能AI助手。
        请以友好、专业的语气回答用户的问题。
        如果用户的问题涉及敏感或不适当的内容，请礼貌地拒绝回答。
        """
    }
]

# 打印欢迎信息
print("=" * 50)
print("DeepSeek 命令行聊天助手")
print("输入 'exit' 或 'quit' 退出程序")
print("输入 'clear' 或 'reset' 清空对话历史")
print("=" * 50)

# 主聊天循环
while True:
    try:
        # 获取用户输入
        user_input = input("\nYou: ").strip()
        
        # 退出命令
        if user_input.lower() in ['exit', 'quit']:
            print("\n对话结束，感谢使用DeepSeek助手！")
            break
            
        # 清空对话历史命令
        if user_input.lower() in ['clear', 'reset']:
            chat_history = [chat_history[0]]  # 保留系统提示
            print("\n[对话历史已重置]")
            continue
            
        # 将用户输入添加到聊天历史
        chat_history.append({"role": "user", "content": user_input})
        
        print("\n思考中...", end="", flush=True)
        
        # 调用DeepSeek API
        response = client.chat.completions.create(
            model="deepseek-reasoner",
            messages=chat_history,
            stream=False
        )
        
        # 获取AI回复
        ai_reply = response.choices[0].message.content.strip()
        
        # 将AI回复添加到聊天历史
        chat_history.append({"role": "assistant", "content": ai_reply})
        
        # 打印AI回复
        print("\r" + " " * 20, end="")  # 清除"思考中..."提示
        print(f"\nAssistant: {ai_reply}")
        
        # 添加短暂延迟防止API限流
        time.sleep(0.3)
        
    except KeyboardInterrupt:
        print("\n\n检测到中断信号，退出程序中...")
        break
    except Exception as e:
        print(f"\n发生错误: {str(e)}")
        print("请稍后重试...")