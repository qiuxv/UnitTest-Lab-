import subprocess
import threading
from queue import Queue
import time
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# 任务队列
task_queue = Queue()

# 待处理的短句列表
phrases = [
    "albatross", "baboon", "backpack", "banana", "basketball", 
    "brown bear", "bullfrog", "cardigan", "cliff", "cockroach", 
    "computer keyboard", "coral reef", "dining table", "dromedary", 
    "Egyptian cat", "espresso", "German shepherd", "goldfish", 
    "guinea pig", "hourglass", "ice cream", "king penguin", 
    "Labrador retriever", "lemon", "maypole", "missile", 
    "monarch butterfly", "nail", "oboe", "parking meter", 
    "pipe organ", "pizza", "plunger", "potpie", "pretzel", 
    "red panda", "reel", "rocking chair", "school bus", 
    "sea cucumber", "seashore", "snail", "sock", "soda bottle", 
    "space heater", "spider web", "sulphur butterfly", "tarantula", 
    "umbrella", "volleyball"
]
"""
phrases = [
    "nail",
    "ice cream",
    "goldfish",
    "potpie",
    "rocking chair",
    "guinea pig",
    "banana",
    "umbrella",
    "pretzel",
    "basketball",
    "space heater",
    "tarantula"
]
"""

# 并发任务数
CONCURRENCY = 3

def worker():
    """工作线程函数，负责执行外部命令"""
    while True:
        # 从队列中获取任务
        phrase = task_queue.get()
        if phrase is None:
            break
            
        try:
            logging.info(f"开始处理: {phrase}")
            
            # 构建命令
            cmd = ["python", "new_usual_genimage.py", phrase]
            
            # 执行外部命令
            result = subprocess.run(
                cmd, 
                capture_output=True, 
                text=True, 
                check=True
            )
            
            logging.info(f"成功完成: {phrase}")
            logging.debug(f"命令输出: {result.stdout}")
            
        except subprocess.CalledProcessError as e:
            logging.error(f"处理失败: {phrase}, 错误: {e.stderr}")
        except Exception as e:
            logging.error(f"发生未知错误: {phrase}, 错误: {str(e)}")
        finally:
            # 标记任务完成
            task_queue.task_done()

def main():
    """主函数，负责初始化队列和工作线程"""
    # 将所有短语加入队列
    for phrase in phrases:
        task_queue.put(phrase)
    
    # 创建工作线程
    threads = []
    for _ in range(CONCURRENCY):
        t = threading.Thread(target=worker)
        t.start()
        threads.append(t)
    
    # 等待所有任务完成
    task_queue.join()
    
    # 停止工作线程
    for _ in range(CONCURRENCY):
        task_queue.put(None)
    for t in threads:
        t.join()
    
    logging.info("所有任务已完成")

if __name__ == "__main__":
    start_time = time.time()
    main()
    end_time = time.time()
    logging.info(f"总耗时: {end_time - start_time:.2f}秒")